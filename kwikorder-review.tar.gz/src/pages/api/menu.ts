// pages/api/menu.ts
export { default } from "./menu/list";
