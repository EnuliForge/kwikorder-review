export default function PingPage() {
  return <main style={{ padding: 16 }}>Ping Page ✓</main>;
}
